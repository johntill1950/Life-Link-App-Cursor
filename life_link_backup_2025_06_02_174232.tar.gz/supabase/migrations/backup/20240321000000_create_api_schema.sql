-- Create api schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS api; 