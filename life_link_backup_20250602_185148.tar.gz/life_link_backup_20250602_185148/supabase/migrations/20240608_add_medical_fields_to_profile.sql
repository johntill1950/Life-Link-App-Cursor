ALTER TABLE profile ADD COLUMN IF NOT EXISTS medical_history text;
ALTER TABLE profile ADD COLUMN IF NOT EXISTS medications text; 